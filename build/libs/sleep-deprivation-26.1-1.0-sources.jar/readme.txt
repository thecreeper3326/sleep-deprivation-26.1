~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
       Guide to configuring SleepDeprivation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  quick reference:
  1 second = 20 ticks
  1 minute = 1200 ticks
  1 in-game day = 24000 ticks

  "interval" integer :
  Number of ticks between events

  "intervalRandomness" integer :
  Amount of deviation from interval (in ticks)

  "stageThreshold1-5" integer :
  Amount of time that must pass without resting
  in order to execute the specified number of
  inventory events

  "stageMultiplier1-5" integer :
  Amount of inventory events that will occur in
  the respective stage

  "includeHotbar" boolean :
  Whether the mod should also target hotbar slots

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    WARNING:
 Too many events happening in a very short period
 of time can result in item deletion/duplication
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
