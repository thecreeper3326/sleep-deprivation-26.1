package net.creeperdev.sleepDeprivation;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.stats.Stats;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import static org.apache.commons.lang3.RandomUtils.*;

public class SleepDeprivation implements ModInitializer {
    public static int counter = 0;
    public static final Logger logger = LoggerFactory.getLogger("Sleep Deprivation - Main");
    @Override
    public void onInitialize() {
        logger.info("Initializing...");
        FigManager.load();
        Figs figs = FigManager.FIGS;
        logger.info("Initialization complete.");
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            counter++;
            if (counter == nextInt(figs.interval - figs.intervalRandomness, figs.interval + figs.intervalRandomness)) {

                for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                    int awakeTime = player.getStats().getValue(Stats.CUSTOM.get(Stats.TIME_SINCE_REST));

                    if (awakeTime > figs.stageThreshold1 && awakeTime < figs.stageThreshold2) {
                        swapItems(player, figs.stageMultiplier1);
                    }
                    if (awakeTime > figs.stageThreshold2 && awakeTime < figs.stageThreshold3) {
                        swapItems(player, figs.stageMultiplier2);
                    }
                    if (awakeTime > figs.stageThreshold3 && awakeTime < figs.stageThreshold4) {
                        swapItems(player, figs.stageMultiplier3);
                    }
                    if (awakeTime > figs.stageThreshold4 && awakeTime < figs.stageThreshold5) {
                        swapItems(player, figs.stageMultiplier4);
                    }
                    if (awakeTime > figs.stageThreshold5) {
                        swapItems(player, figs.stageMultiplier5);
                    }
                }
                counter = 0;
            }
        });

    }

    public static void swapItems(ServerPlayer player, int times) {

        Figs figs = FigManager.FIGS;
        int e = nextInt(0, 3);
        for (int i = 0; i < times; i++) {
            if (e > 0) {
                Inventory inventory = player.getInventory();
                int slotA = nextInt(9, 35);
                ItemStack itemStackA = inventory.getItem(slotA);
                int slotB = nextInt(9, 35);
                ItemStack itemStackB = inventory.getItem(slotB);
                if (slotA != slotB) {
                    inventory.setItem(slotA, ItemStack.EMPTY);
                    inventory.setItem(slotB, ItemStack.EMPTY);
                    inventory.setItem(slotA, itemStackB);
                    inventory.setItem(slotB, itemStackA);
                }
                inventory.setChanged();
            } else if (e == 0) {
                if (figs.includeHotbar) {
                    Inventory inventory = player.getInventory();
                    int slotA = nextInt(0, 8);
                    ItemStack itemStackA = inventory.getItem(slotA);
                    int slotB = nextInt(0, 8);
                    ItemStack itemStackB = inventory.getItem(slotB);
                    if (slotA != slotB) {
                        inventory.setItem(slotA, ItemStack.EMPTY);
                        inventory.setItem(slotB, ItemStack.EMPTY);
                        inventory.setItem(slotA, itemStackB);
                        inventory.setItem(slotB, itemStackA);
                    }
                    inventory.setChanged();
                } else {
                    Inventory inventory = player.getInventory();
                    int slotA = nextInt(9, 35);
                    ItemStack itemStackA = inventory.getItem(slotA);
                    int slotB = nextInt(9, 35);
                    ItemStack itemStackB = inventory.getItem(slotB);
                    if (slotA != slotB) {
                        inventory.setItem(slotA, ItemStack.EMPTY);
                        inventory.setItem(slotB, ItemStack.EMPTY);
                        inventory.setItem(slotA, itemStackB);
                        inventory.setItem(slotB, itemStackA);
                    }
                    inventory.setChanged();
                }
            }
        }
    }
}
