package net.creeperdev.sleepDeprivation;

public class Figs {
    public int interval  = 400;
    public int intervalRandomness = 100;
    public int stageThreshold1 = 12000;
    public int stageThreshold2 = 24000;
    public int stageThreshold3 = 32000;
    public int stageThreshold4 = 40000;
    public int stageThreshold5 = 52000;
    public int stageMultiplier1 = 1;
    public int stageMultiplier2 = 2;
    public int stageMultiplier3 = 4;
    public int stageMultiplier4 = 8;
    public int stageMultiplier5 = 10;
    public boolean includeHotbar = true;
    public String note = "Refer to config_guide.txt for instructions on configuring!";
}
